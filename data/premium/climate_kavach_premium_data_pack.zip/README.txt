India-ROADS Premium Data Pack

This pack is intentionally stored outside /public and is served only by the protected API route after server-side verification.

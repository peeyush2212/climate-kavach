# Premium coefficient notes

The India-ROADS emulator combines Kaya decomposition, panel-calibrated energy-intensity and carbon-intensity elasticities, physical grid-loss scaling, and a simplified carbon-cycle impulse response.
